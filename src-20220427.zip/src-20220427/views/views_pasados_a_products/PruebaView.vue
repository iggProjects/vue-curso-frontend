<script setup>
  import WelcomeTable from '../components/WelcomeTable.vue'
</script>

<template>
        <WelcomeTable />
</template>



